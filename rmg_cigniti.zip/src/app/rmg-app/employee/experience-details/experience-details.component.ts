import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'val-experience-details',
  templateUrl: './experience-details.component.html',
  styleUrls: ['./experience-details.component.scss']
})
export class ExperienceDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
