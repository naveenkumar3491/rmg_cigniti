import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'val-visa-details',
  templateUrl: './visa-details.component.html',
  styleUrls: ['./visa-details.component.scss']
})
export class VisaDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
