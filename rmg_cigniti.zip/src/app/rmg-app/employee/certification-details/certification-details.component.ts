import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'val-certification-details',
  templateUrl: './certification-details.component.html',
  styleUrls: ['./certification-details.component.scss']
})
export class CertificationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
