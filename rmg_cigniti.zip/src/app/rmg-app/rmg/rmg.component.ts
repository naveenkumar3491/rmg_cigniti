import {Component} from '@angular/core';

@Component({
  selector: 'val-rmg',
  templateUrl: './rmg.component.html',
  styleUrls: ['./rmg.component.css']
})
export class RmgComponent {

 



}
